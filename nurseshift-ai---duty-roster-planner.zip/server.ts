
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { db } from "./services/db";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket } from "ws";
import { createServer } from "http";

console.log("SERVER.TS STARTING...");
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer });
  const PORT = process.env.PORT || 3000;

  // WebSocket broadcast helper
  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  wss.on("connection", (ws) => {
    console.log("New WebSocket connection established");
    ws.send(JSON.stringify({ type: "connected", message: "Real-time roster tracking active" }));
  });

  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  app.get("/ping", (req, res) => {
    res.send("pong");
  });

  let dbReady = false;

  // Initialize Database (non-blocking)
  db.init().then(() => {
    dbReady = true;
    console.log("Database initialized successfully");
  }).catch(err => {
    console.error("Failed to initialize database:", err);
  });

  // Health Check
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: dbReady ? "ok" : "error", 
      db: process.env.DB_TYPE || 'memory',
      dbReady,
      env: process.env.NODE_ENV || 'development'
    });
  });

  app.get("/api/test", (req, res) => {
    res.json({ success: true, message: "API is reachable" });
  });

  // API Routes
  app.use("/api", (req, res, next) => {
    if (req.path === "/health" || req.path === "/test") return next();
    if (!dbReady) {
      console.warn(`API attempt rejected (${req.path}): Database not ready`);
      return res.status(503).json({ 
        success: false, 
        message: "Database is not ready. Please check your configuration." 
      });
    }
    next();
  });

  app.post("/api/login", async (req, res) => {
    console.log(`Login attempt for: ${req.body?.email}`);
    const { email, password } = req.body;
    try {
      const result = await db.login(email, password);
      if (result) {
        console.log(`Login successful for: ${email}`);
        res.json({ success: true, ...result });
      } else {
        console.log(`Login failed (invalid credentials) for: ${email}`);
        res.status(401).json({ success: false, message: "Invalid credentials" });
      }
    } catch (err: any) {
      console.error("Login error:", err);
      res.status(500).json({ 
        success: false, 
        message: "Server error", 
        details: process.env.NODE_ENV === 'development' ? err.message : undefined 
      });
    }
  });

  app.post("/api/login/firebase", async (req, res) => {
    const { email, uid } = req.body;
    console.log(`Firebase login verification for: ${email}`);

    try {
      // Check if user is an admin
      const admins = await db.getAdmins();
      const admin = admins.find(a => a.email.toLowerCase() === email.toLowerCase());
      if (admin) {
        return res.json({ success: true, role: admin.role, user: admin });
      }

      // Check if user is a nurse
      const nurses = await db.getNurses();
      const nurse = nurses.find(n => n.email.toLowerCase() === email.toLowerCase());
      if (nurse) {
        return res.json({ success: true, role: 'nurse', user: nurse });
      }

      res.status(401).json({ success: false, message: "User not found in hospital registry" });
    } catch (err) {
      console.error("Firebase login verification error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  });

  // Request Logger
  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });

  app.get("/api/nurses", async (req, res) => {
    try {
      const nurses = await db.getNurses();
      res.json(nurses);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/nurses", async (req, res) => {
    try {
      const nurse = await db.addNurse(req.body);
      broadcast({ type: "nurse_added", data: nurse });
      res.json(nurse);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/nurses/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const nurse = await db.updateNurse(id as any, req.body);
      broadcast({ type: "nurse_updated", data: nurse });
      res.json(nurse);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/duties", async (req, res) => {
    try {
      const duties = await db.getDuties();
      res.json(duties);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/duties", async (req, res) => {
    try {
      const duty = await db.addDuty(req.body);
      broadcast({ type: "duty_added", data: duty });
      res.json(duty);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/duties/bulk", async (req, res) => {
    try {
      const duties = req.body;
      const savedDuties = await db.addDutiesBulk(duties);
      broadcast({ type: "duties_added", data: savedDuties });
      res.json(savedDuties);
    } catch (err) {
      console.error("Bulk duty assignment error:", err);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/duties/month/:year/:month", async (req, res) => {
    try {
      const { year, month } = req.params;
      const duties = await db.getDuties();
      const toDelete = duties.filter(d => {
        const date = new Date(d.date);
        return date.getFullYear() === parseInt(year) && date.getMonth() === parseInt(month);
      });
      const deletedIds = [];
      for (const d of toDelete) {
        await db.deleteDuty(d.id as any);
        deletedIds.push(d.id);
      }
      broadcast({ type: "duties_deleted", data: deletedIds });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/duties/bulk-status", async (req, res) => {
    try {
      const { dutyIds, status } = req.body;
      await db.updateDutiesStatusBulk(dutyIds, status);
      broadcast({ type: "duties_updated_bulk", data: { dutyIds, status } });
      res.json({ success: true });
    } catch (err) {
      console.error("Bulk status update error:", err);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/duties/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const duty = await db.updateDuty(id as any, req.body);
      broadcast({ type: "duty_updated", data: duty });
      res.json(duty);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/duties/:id", async (req, res) => {
    try {
      const id = req.params.id;
      await db.deleteDuty(id as any);
      broadcast({ type: "duty_deleted", data: id });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await db.getMessages();
      res.json(messages);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const message = await db.addMessage(req.body);
      broadcast({ type: "message_added", data: message });
      res.json(message);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/messages/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const message = await db.updateMessage(id as any, req.body);
      broadcast({ type: "message_updated", data: message });
      res.json(message);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production" && process.env.DISABLE_VITE !== "true") {
    console.log("Starting in development mode with Vite middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in production mode...");
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(Number(PORT), "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
